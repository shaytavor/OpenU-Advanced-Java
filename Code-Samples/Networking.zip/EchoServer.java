/*
 * EchoServer.java
 *
 * Author: Shay Tavor, shay.tavor@gmail.com
 *
 * Represents a server that echo client's strings.
 */


import java.net.*;
import java.io.*;
/**
 *
 * @author Shay Tavor
 */
public class EchoServer {
    public static void main(String[] args)
    {
        ServerSocket srv = null;
        try {
            srv = new ServerSocket(7777);
            System.out.println("Server's ready");
            Socket socket = null;
            socket = srv.accept();
            PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
            BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            String input;
            input = in.readLine();
            while(input != null)
            {
                out.println("Server:" + input);
                input = in.readLine();
            }
             out.close();
             in.close();
             socket.close();
             srv.close();
         }
        catch(IOException e)
        {
            e.printStackTrace();
        }
        
    }
  
}

/*
 * Main.java
 *
 * Author: Shay Tavor, shay.tavor@gmail.com
 *
 * A tester for networking issues.
 */



/**
 *
 * @author Shay Tavor
 */
import java.net.*;
import java.io.*;
import javax.swing.JOptionPane;
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       Networking net = new Networking();
   
       String urlString = "http://www.openu.ac.il";
       net.urlAttributes(urlString);
  //     String s = net.readFromURL(urlString);
     //  System.out.println(s);
    //   net.writeToURL(urlString, "Hello");
    }
    
}

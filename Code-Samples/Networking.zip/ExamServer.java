/*
 * ExamServer.java
 *
 * Author: Shay Tavor, shay.tavor@gmail.com
 *
 * Exam Server - sends questions to client
 */


import java.net.*;
import java.io.*;
/**
 *
 * @author Shay Tavor
 */
public class ExamServer {
    
    public static void main(String[] args)
    {
        ServerSocket srv = null;
        boolean listening = true;
        try {
            srv = new ServerSocket(8888);
            while(listening)
                new ExamThread(srv.accept()).start();
            srv.close();         
        }
        catch(IOException e){ e.printStackTrace(); }
    }
    
}

/*
 * Networking.java
 *
 * Author: Shay Tavor, shay.tavor@gmail.com
 *
 * This class includes various examples from the networking lesson
 */



/**
 *
 * @author Shay Tavor
 */
import java.net.*;
import java.io.*;
import javax.swing.JOptionPane;

public class Networking {
    
   public void urlAttributes(String urlString)
   {
       URL url = null;
        try {
            url = new URL(urlString);
            String s = "";
            s = "Host: " + url.getHost()  + "\n";
            s = s + "Protocol: " + url.getProtocol() + "\n";
            s = s + "Prot: " + url.getPort() + "\n";
            JOptionPane.showMessageDialog(null, s);
        } catch (MalformedURLException ex) {
            ex.printStackTrace();
        }
       
   }
    // Reads directly from a url
   public String readFromURL(String url)
   {
       String res = "";
       URL source;
       try{
           source = new URL(url);
           BufferedReader in = new BufferedReader(new InputStreamReader(source.openStream()));
           String s;
           s = in.readLine();
           while(s != null)
           {
               res = res + s + "\n";
               s = in.readLine();
           }
           in.close();
       }
       catch(MalformedURLException e)
       {
           e.printStackTrace();
       }
       catch(IOException e)
       {
           e.printStackTrace();
       }
       finally
       {
           return res;
       }
   }
   
   // Writes to url
   public void writeToURL(String url, String str)
{
	URL target;
	try {
		target = new URL(url);
		String toWrite=URLEncoder.encode(str, "UTF-8");
		URLConnection con = target.openConnection();
		con.setDoOutput(true);
		OutputStreamWriter out = new OutputStreamWriter(con.getOutputStream());
		out.write(toWrite);
		out.close();
	}
	catch(MalformedURLException e){e.printStackTrace();}
	catch(IOException e){e.printStackTrace();}
}

  
}
     


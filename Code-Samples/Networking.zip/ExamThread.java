/*
 * ExamThread.java
 *
 * Author: Shay Tavor, shay.tavor@gmail.com
 *
 * Handles a single exam client
 */


import java.net.*;
import java.io.*;
/**
 *
 * @author Shay Tavor
 */
public class ExamThread extends Thread{
    private String[] questions = {"Q1", "Q2", "Q3"};
    private String[] answers = {"true", "false", "true"};
    private int score = 0;
    private Socket socket;
    /** Creates a new instance of ExamThread */
    public ExamThread(Socket s) {
        socket = s;
    }
    
    public void run()
    {
        PrintWriter out = null;
        BufferedReader in = null;
        try {
            out = new PrintWriter(socket.getOutputStream(), true);
            in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            for(int i = 0; i < questions.length; i++)
            {
                out.println(questions[i]);
                String res = in.readLine();
                if(res.equals(answers[i]))
                    score++;
            }
            out.println(score);
            out.close();
            in.close();
            socket.close();
        }
        catch(IOException e){ e.printStackTrace(); }
    }
    
}

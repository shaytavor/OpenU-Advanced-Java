/*
 * UDPServer.java
 *
 * Author: Shay Tavor, shay.tavor@gmail.com
 *
 * UDP server, sends "Hello"
 */



import java.io.IOException;
import java.net.*;

/**
 *
 * @author Shay Tavor
 */
public class UDPServer {
    
    public static void main(String[] args)
    {
        try{
            DatagramSocket socket = new DatagramSocket(7777);
            System.out.println("Server's Ready");
            byte[] buf = new byte[256];
            DatagramPacket packet = new DatagramPacket(buf, buf.length);
            socket.receive(packet);
            String response = "Hello";
            buf = response.getBytes();
            InetAddress address = packet.getAddress();
            int port = packet.getPort();
            packet = new DatagramPacket(buf, buf.length, address, port);
            socket.send(packet);
        }
        catch(IOException e){ e.printStackTrace(); }

    }
    
}

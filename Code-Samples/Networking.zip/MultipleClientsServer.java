/*
 * MultipleClientsServer.java
 *
 * Author: Shay Tavor, shay.tavor@gmail.com
 *
 * A server that handles multiple clients
 */


import java.net.*;
import java.io.*;
/**
 *
 * @author Shay Tavor
 */
public class MultipleClientsServer {
    public static void main(String[] args)
    {
        ServerSocket srv = null;
        boolean listening = true;
        try {
            srv = new ServerSocket(7777);
        //    srv.setSoTimeout(5000);
            System.out.println("Server's ready");
            Socket socket = null;
            
            while(listening)
            {
                socket = srv.accept();
                new EchoThread(socket).start();
            }         
        }
        catch(InterruptedIOException e)
        {
            System.out.println("Time out");
        }
        catch(IOException e)
        { 
            e.printStackTrace(); 
            System.exit(1);
        }
        
        
        
    }
  
}

/*
 * UDPClient.java
 *
 * Author: Shay Tavor, shay.tavor@gmail.com
 *
 * UDP client
 */


import java.io.IOException;
import java.net.*;
/**
 *
 * @author Shay Tavor
 */
public class UDPClient {
    
    public static void main(String[] args)
    {
        try {
            DatagramSocket socket = new DatagramSocket();
            byte[] buf = new byte[256];
            InetAddress a = InetAddress.getByName("localhost");
            DatagramPacket p = new DatagramPacket(buf, buf.length, a, 7777);
            socket.send(p);
            p = new DatagramPacket(buf, buf.length);
            socket.receive(p);
            String data = new String(p.getData(), 0, p.getLength());
            System.out.println("Server:" + data);
        }
        catch(IOException e){ e.printStackTrace(); }
    }
    
}

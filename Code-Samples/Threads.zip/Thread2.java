
import javax.swing.JTextArea;

/*
 * Thread2.java
 *
 * Author: Shay Tavor, shay.tavor@gmail.com
 *
 * Calls Thread1 and wait until it's done.
 */

/**
 *
 * @author Shay Tavor
 */
// Thread2 No Locks

public class Thread2 extends Thread{
    private boolean stop = false;
    private JTextArea output;
    public Thread2(JTextArea txt)
    {
        output = txt;
    }
   public  synchronized void run()
   {
       Thread1 t = new Thread1(this, output);
      
       t.start();
        
       while(!stop)
       {
           try
           {
            wait();
           }
           catch(InterruptedException e){}
       }
      // System.out.println("Finished");
       output.append("Finished" + "\n");
       
   }
  
   public synchronized void setStop()
   {
       stop = true;
       notify();
   }
}


// Thread2 with locks
/*
import java.util.concurrent.locks.*;

public class Thread2 extends Thread{
    private boolean stop = false;
    private Lock l = new ReentrantLock();
   private Condition c = l.newCondition();
   private JTextArea output;
   public Thread2(JTextArea txt)
   {
       output = txt;
   }
   public  void run()
   {
       Thread1 t = new Thread1(this, output);
      
       t.start();
       
       l.lock(); 
       while(!stop)
       {
           try
           {
            c.await();
           }
           catch(InterruptedException e){}
       }
       l.unlock();
       //System.out.println("Finished");
       output.append("Finished");
       
   }
   
  
   public void setStop()
   {
       l.lock();
       stop = true;
       c.signal();
       l.unlock();
   }
}
 */

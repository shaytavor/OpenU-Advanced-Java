/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Shay Tavor
 */
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import javax.swing.*;

public class ThreadsGUI extends JPanel {
     private JButton cmdBusyWaiting;
    private JButton cmdClear;
    private JButton cmdMoving;
    private JButton cmdPrimes;
    private JButton cmdPrint;
    private JButton cmdProduct;
    private JButton cmdSleeping;
    private JButton cmdAccount;
    private JLabel lblTitle;
    private JScrollPane jScrollPane1;
    private JTextArea txtOutput;

    public ThreadsGUI()
    {
        cmdBusyWaiting = new JButton("Budy Waiting");
        cmdClear = new JButton("Clear");
        cmdMoving = new JButton("Moving Balls");
        cmdPrimes = new JButton("Primes");
        cmdPrint = new JButton("Printing");
        cmdProduct = new JButton("Product");
        cmdSleeping = new JButton("Sleeping");
        cmdAccount = new JButton("Account");
        lblTitle = new JLabel("Multithreading");
         txtOutput = new JTextArea(10, 20);
        jScrollPane1 = new JScrollPane(txtOutput);
        txtOutput.setFont(new java.awt.Font("Courier New", 0, 24));
        lblTitle.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        lblTitle.setForeground(new java.awt.Color(0, 0, 255));
        jScrollPane1.setViewportView(txtOutput);

        JPanel buttons = new JPanel();
        buttons.setLayout(new GridLayout(3, 3, 20, 20));
        buttons.add(cmdPrint);
        buttons.add(cmdSleeping);
        buttons.add(cmdMoving);
        buttons.add(cmdAccount);
        buttons.add(cmdProduct);
        buttons.add(cmdBusyWaiting);
        buttons.add(cmdPrimes);
        buttons.add(cmdClear);

        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        add(lblTitle);
        add(Box.createVerticalGlue());
        add(buttons);
        add(Box.createVerticalGlue());
        add(jScrollPane1);

        Listener l = new Listener();
        cmdPrint.addActionListener(l);
        cmdSleeping.addActionListener(l);
        cmdMoving.addActionListener(l);
        cmdAccount.addActionListener(l);
        cmdProduct.addActionListener(l);
        cmdBusyWaiting.addActionListener(l);
        cmdPrimes.addActionListener(l);
        cmdClear.addActionListener(l);
    }

    private class Listener implements ActionListener
    {
        public void actionPerformed(ActionEvent e)
        {
            if(e.getSource() == cmdPrint)
            {
                PrintingThread t1 = new PrintingThread('*', txtOutput);
                PrintingThread t2 = new PrintingThread('#', txtOutput);
                t1.start();
                t2.start();
        //        ExecutorService ex = Executors.newFixedThreadPool(2);
        //        ex.execute(new PrintingThread('*', txtOutput));
        //        ex.execute(new PrintingThread('#', txtOutput));
        //        ex.shutdown();
            }
            else if(e.getSource() == cmdSleeping)
            {
                Sleeping s1 = new Sleeping("s1", txtOutput);
                Sleeping s2 = new Sleeping("s2", txtOutput);
                Sleeping s3 = new Sleeping("s3", txtOutput);
                s1.start();
                s2.start();
                s3.start();
            }
            else if(e.getSource() == cmdMoving)
            {
                JFrame frame = new JFrame("Moving Balls");
                frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
                frame.setSize(600, 600);
                MovingBalls m = new MovingBalls();
                frame.add(m);
                frame.setVisible(true);
            }
            else if(e.getSource() == cmdAccount)
            {
                Account a = new Account(1000);
                TransactionThread t = new TransactionThread(a);
                GetBalanceThread g = new GetBalanceThread(a, txtOutput);
                t.start();
                g.start();
            }
            else if(e.getSource() == cmdProduct)
            {
                Product prod = new Product(txtOutput);
                Producer p = new Producer(prod, txtOutput);
                Consumer c = new Consumer(prod, txtOutput);
                p.start();
                c.start();
            }
            else if(e.getSource() == cmdBusyWaiting)
            {
                Thread2 t = new Thread2(txtOutput);
                t.start();
            }
            else if(e.getSource() == cmdPrimes)
            {
                final int N = 100, T = 5;
                Controller c = new Controller(T, N);
                for(int i=2; i<c.numbers.length; i++)
                {
                    c.waitForThread();
                    (new PrimeThread(i, c)).start();
                }
                c.waitForAll();
                txtOutput.setText(c.printResults());
            }
            else if(e.getSource() == cmdClear)
            {
                txtOutput.setText("");
            }
        }
    }
}


import javax.swing.JTextArea;

/*
 * Consumer.java
 * Author: Shay Tavor, shay.tavor@gmail.com
 *
 * Represents a consumer in mutex code
 */

/**
 *
 * @author Shay Tavor
 */
public class Consumer extends Thread {
    private Product p;
    private JTextArea output;
    public Consumer(Product p, JTextArea txt) {
        this.p = p;
        output = txt;
    }
    
    public void run()
    {
        int val;
        do {
            val = p.consume();
            try {
                Thread.sleep((long)(Math.random()*100));
            }
            catch(InterruptedException e) {}
        }while(val!=10);
      //  System.out.println("Finished Consuming");
        output.append("Finished Consuming" + "\n");
    }
    
    
}

/*
 * This thread performs a transaction
 */

/**
 *
 * @author Shay Tavor
 */
public class TransactionThread extends Thread {
    private Account account;
    public TransactionThread(Account a)
    {
        account = a;
    }

    @Override
    public void run()
    {
        account.transaction(1000000);
    }

}

/*
 * Represents a bank account
 */

/**
 *
 * @author Shay Tavor
 */
public class Account {
    private double  balance;
    public Account(double balance)
    {
        this.balance = balance;
    }
    public  void transaction(double amount)
    {
        int add = (amount > 0) ? 1 : -1;
        for(int i = 1; i <= Math.abs(amount); i++)
            balance += add;
    }

    public  double getBalance()
    {
        return balance;
    }
}


import javax.swing.JTextArea;

// Sleeping.java
// Demonstrates the Thread's sleep() method
// Author: Shay Tavor, shay.tavor@gmail.com
public class Sleeping extends Thread
{
	private int sleepTime;
    private JTextArea txtOutput;
	public Sleeping(String name, JTextArea txt)
	{
		super(name);
		sleepTime = (int)(Math.random()*5000);
        txtOutput = txt;
	}
	public void run()
	{
	//	System.out.println(getName() + " is sleeping");
        txtOutput.append(getName() + " is sleeping" + "\n");
		try {
			Thread.sleep(sleepTime);
		}
		catch(InterruptedException e){ }
		//System.out.println(getName() + " woke up");
        txtOutput.append(getName() + " woke up" + "\n");
	}
}

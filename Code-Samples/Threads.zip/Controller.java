
import javax.swing.JTextArea;

/*
 * Controller.java
 *
 * Author: Shay Tavor, shay.tavor@gmail.com
 *
 * Runs the prime threads
 */

/**
 *
 * @author Shay Tavor
 */
// Controller no locks

public class Controller {
    
    private int maxThreads, activeThreads, currentNumbers;
    public boolean[] numbers;

    public Controller(int max, int totalNums) {
        maxThreads = max;
        activeThreads = currentNumbers = 0;
        numbers = new boolean[totalNums+1];
        for(int i=0; i<numbers.length; i++)
            numbers[i] = false;
        
    }
    
    public synchronized void waitForThread()
    {
        while(activeThreads == maxThreads)
            try{
                wait();
            }
            catch(InterruptedException e){}
    }
    
    public synchronized void finished()
    {
        activeThreads--;
        currentNumbers++;
        notifyAll();
    }
    
    public synchronized void waitForAll()
    {
        while(currentNumbers < numbers.length-2)
            try {
               wait();
            }
            catch(InterruptedException e){}
    }
    
    public String printResults()
    {
        String res = "";
        for(int i=2; i<numbers.length; i++)
            if(numbers[i])
                res = res + i + "\n";
        return res;
    }
}


// Controller with locks
/*
import java.util.concurrent.locks.*;

public class Controller {
    
    private int maxThreads, activeThreads, currentNumbers;
    public boolean[] numbers;
    private Lock l;
    private Condition cond;
    public Controller(int max, int totalNums) {
        maxThreads = max;
        activeThreads = currentNumbers = 0;
        numbers = new boolean[totalNums+1];
        l = new ReentrantLock();
        cond = l.newCondition();
        for(int i=0; i<numbers.length; i++)
            numbers[i] = false;
    }
    
    public void waitForThread()
    {
        l.lock();
        while(activeThreads == maxThreads)
            try{
                cond.await();
            }
            catch(InterruptedException e){}
        l.unlock();
    }
    
    public void finished()
    {
        l.lock();
        activeThreads--;
        currentNumbers++;
        cond.signalAll();
        l.unlock();
    }
    
    public void waitForAll()
    {
        l.lock();
        while(currentNumbers < numbers.length-2)
            try {
                cond.await();
            }
            catch(InterruptedException e){}
        l.unlock();
    }
    
    public String printResults()
    {
        String res = "";
        for(int i=2; i<numbers.length; i++)
            if(numbers[i])
                res = res + i + "\n";
        return res;
    }
}
*/

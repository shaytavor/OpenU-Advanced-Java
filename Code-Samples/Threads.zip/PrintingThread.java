
import javax.swing.JTextArea;

/*
 * PrintingThread.java
 * Prints a certain sign 1000 times
 * Written by Shay Tavor, shay.tavor@gmail.com
 */

/**
 *
 * @author Shay Tavor
 */
public class PrintingThread extends Thread {
    private char sign;
    private JTextArea txtOutput;
    public PrintingThread(char s, JTextArea txt) {
        sign = s;
        txtOutput = txt;
    }
    
    public void run()
    {
        for(int i=1; i<=3000; i++)
           // System.out.print(sign);
        {
            txtOutput.append(sign + "");
            if(i % 20 == 0)
                txtOutput.append("\n");
        }
        
    }
    
}


import javax.swing.JTextArea;

/*
 * Get balance from account
 */

/**
 *
 * @author Shay Tavor
 */
public class GetBalanceThread extends Thread {
    private Account account;
    JTextArea output;
    public GetBalanceThread(Account a, JTextArea txt)
    {
        account = a;
        output = txt;
    }

    @Override
    public void run()
    {
        output.append("" + account.getBalance() + "\n");
    }

}

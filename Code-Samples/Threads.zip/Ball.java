// Ball.java
// Author: Shay Tavor, shay.tavor@gmail.com
// Represents a moving object as a Thread.

public class Ball implements Runnable
{
	private int x, y, delay;
	private int xInterval, yInterval;
	private MovingBalls frame;
    private final int INTERVAL = 10;
	public Ball(int x, int y, MovingBalls m)
	{
		this.x = x;
		this.y = y;
		this.delay = (int)(Math.random()*100);
		frame = m;
        xInterval = (int)(Math.random()*10) % 2 == 0 ? INTERVAL : -1 * INTERVAL;
        yInterval = (int)(Math.random()*10) % 2 == 0 ? INTERVAL : -1 * INTERVAL;
	}
	public void run()
	{
		while(true)
		{		
			x += xInterval;
            y += yInterval;
			if(x + 10 >= frame.getWidth() || x <= 0)
				xInterval *= -1;
            if(y + 20 >= frame.getWidth() || y <= 10)
                yInterval *= -1;
			frame.repaint();
			try{
				Thread.sleep(delay);
			}
			catch(InterruptedException e){}
		}
	}
	public int getX() { return x; }
	public int getY() { return y; }
}

/*
 * PrimeThread.java
 *
 * Author: Shay Tavor, shay.tavor@gmail.com
 *
 * Calculate if a given number is prime.
 */

/**
 *
 * @author Shay Tavor
 */
public class PrimeThread extends Thread {
    private int num;
    private Controller cont;
    
    public PrimeThread(int n, Controller c) {
        num = n;
        cont = c;
    }
    
    public void run()
    {
        int i;
        for(i = 2; i<num; i++)
            if(num % i == 0)
                break;
        if(i == num)
            cont.numbers[i] = true;
        cont.finished();
    }
    
}

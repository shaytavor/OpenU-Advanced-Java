
import javax.swing.JTextArea;

/*
 * Thread1.java
 *
 * Author: Shay Tavor, shay.tavor@gmail.com
 *
 * prints all numbers from 1 to 100
 */

/**
 *
 * @author Shay Tavor
 */

public class Thread1 extends Thread {
    private Thread2 t;
    private JTextArea output;
    public Thread1(Thread2 t, JTextArea txt)
    {
        this.t = t;
        output = txt;
    }
    
    public  void run()
    {
        for(int i=1; i<100; i++)
         //   System.out.println("" + i);
            output.append("" + i + "\n");
          
        t.setStop();
      
    }
    
}



import javax.swing.JTextArea;

/*
 * Producer.java
 * Author: Shay Tavor, shay.tavor@gmail.com
 *
 * Represents a producer in mutex code
 */

/**
 *
 * @author Shay Tavor
 */
public class Producer extends Thread {
    private Product p;
    private JTextArea output;
    public Producer(Product p, JTextArea txt)
    {
        this.p = p;
        output = txt;
    }
    
    public void run()
    {
        for(int i=1; i<=10; i++)
        {
           p.produce(i);
           try {
               Thread.sleep((long)(Math.random()*100));
            }
           catch(InterruptedException e){}
        }
   //     System.out.println("Finished Producing");
        output.append("Finished Producing" + "\n");
        
    }
}
   


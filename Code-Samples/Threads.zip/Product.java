
import javax.swing.JTextArea;

// Product.java
// Author: Shay Tavor, shay.tavor@gmail.com
// Represents a product. Contains two versions - unsynchronized and synchronized

// Product - unsynchronized
public class Product 
{
	private int num;
    private JTextArea output;
	public Product(JTextArea txt)
    {
        num = 0;
        output = txt;
    }
	public void produce(int n)
	{	
		//System.out.println("Producing " + n);
        output.append("producing " + n + "\n");
		num = n;
	}
	public int consume()
	{ 	
		//System.out.println("Consuming " + num);
        output.append("Consuming " + num + "\n");
		return num;
	}	
}

// Product - Synchronized
/*
public class Product
{
	private int num;
	private boolean toProduce;
    private JTextArea output;
    public Product(JTextArea txt)
    {
        num = 0;
        output = txt;
        toProduce = true;
    }
    
	public synchronized void produce(int n)
	{
		while(!toProduce)
			try { wait(); }
			catch(InterruptedException e) {}
		//System.out.println("Producing " + n);
        output.append("Producing " + n + "\n");
		num = n;
		toProduce = false;
		notifyAll();
	}
	public synchronized int consume()
	{
		while(toProduce)
			try { wait(); }
			catch(InterruptedException e) {}
	//	System.out.println("Consuming " + number);
        output.append("Consuming " + num + "\n");
		toProduce = true;
		notifyAll();
		return num;
	}
}
 */


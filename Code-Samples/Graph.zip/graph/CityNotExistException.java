

package graph;

/**
 *
 * @author Shay
 */
public class CityNotExistException extends Exception {

    public CityNotExistException(String msg) {
        super(msg);
    }

}

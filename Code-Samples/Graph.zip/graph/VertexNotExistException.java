/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package graph;

/**
 *
 * @author Shay
 */
public class VertexNotExistException extends Exception  {
    public VertexNotExistException(String msg)
    {
        super(msg);
    }
}

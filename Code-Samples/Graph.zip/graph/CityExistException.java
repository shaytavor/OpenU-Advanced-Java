
package graph;

/**
 *
 * @author Shay
 */
public class CityExistException extends Exception {
    public CityExistException(String msg)
    {
        super(msg);
    }
}

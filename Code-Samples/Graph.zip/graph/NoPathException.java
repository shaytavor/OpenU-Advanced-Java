

package graph;

/**
 *
 * @author Shay
 */
public class NoPathException extends Exception  {

    public NoPathException(String msg) {
        super(msg);
    }

}
